@echo off
call "%~dp0windows-watchdog\instalar-watchdog.bat"
exit /b %ERRORLEVEL%
